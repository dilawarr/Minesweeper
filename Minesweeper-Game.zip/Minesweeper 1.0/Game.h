#pragma once
#include<iostream>
#include <SFML/Graphics.hpp>
#include <Windows.h>
#include <fstream>

///////////////////////Parent Class//////////////////////////////

class Gamemode
{
    int maxRows;
    int maxCol;
    int scale;
    int numMines;

public:
    Gamemode()
    {
        maxRows = 0;
        maxCol = 0;
        scale = 0;
        numMines = 0;
    }
    Gamemode(int rows, int col, int scaling, int mines)
    {
        maxRows = rows;
        maxCol = col;
        scale = scaling;
        numMines = mines;
    }
    int getRows()
    {
        return maxRows;
    }
    int getCol()
    {
        return maxCol;
    }
    int getScale()
    {
        return scale;
    }
    int getMines()
    {
        return numMines;
    }

    bool checkWin();
    void zeroClick(const int& i, const int& j);
    void openBoard(const int& row, const int& col);
    void mouseHoverPos(const int& x, const int& y, int& row, int& col);
    void drawView(sf::RenderWindow& window);
    void displayTimer(const sf::Time& time, sf::RenderWindow& window);
    void displayNumMines(sf::RenderWindow& window);

    void gameLoop();

    friend class EasyGame;
    friend class MediumGame;
    friend class HardGame;
};

////////////////////////Function Prototypes/////////////////////////////

void chooseGame(const int& difficulty);
bool checkLeaderboard(const int& userScore);

///////////////////////////Global Variables/////////////////////////

int remMines;

int difficulty = 1;

int boardEasy[16][30] = { 0 };
int viewEasy[16][30] = { 0 };
bool openEasy[16][30] = { 0 };
bool flagEasy[16][30] = { 0 };

///////////////////////////Utility Fuctions of Global Variables//////////////////////////////////////////

void setMine(int sizeX, int sizeY, int numMines)
{
    remMines = numMines;
repeat:  int num = numMines;
    srand(time(0));
    for (int i = 0; i < sizeX && num != 0; i++)
    {
        for (int j = 0; j < sizeY && num != 0; j++)
        {
            viewEasy[i][j] = -1;
            flagEasy[i][j] = 0;
            openEasy[i][j] = 0;
            if (rand() % (10 - difficulty * 2) == 0 && num != 0)
            {
                boardEasy[i][j] = 9;
                num--;
            }
            else
                boardEasy[i][j] = 0;
        }
    }

    if (num != 0)
    {
        for (int i = 0; i < sizeX; i++)
            for (int j = 0; j < sizeY; j++)
                boardEasy[i][j] = 0;
        goto repeat;
    }

    for (int i = 0; i < sizeX; i++)
    {
        for (int j = 0; j < sizeY; j++)
        {
            int count = 0;
            if (boardEasy[i][j] != 9)
            {
                if (i == 0 && j == 0)
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j + 1] == 9)
                        count++;
                }
                else if (i == 0 && j == sizeY - 1)
                {
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j - 1] == 9)
                        count++;
                }
                else if (i == sizeX - 1 && j == 0)
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j + 1] == 9)
                        count++;
                }
                else if (i == sizeX - 1 && j == sizeY - 1)
                {
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j - 1] == 9)
                        count++;
                }

                else if (i == 0)
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j + 1] == 9)
                        count++;
                }
                else if (i == sizeX - 1)
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j - 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j + 1] == 9)
                        count++;
                }

                else if (j == 0)
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j + 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j + 1] == 9)
                        count++;
                }

                else if (j == sizeY - 1)
                {
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j - 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j - 1] == 9)
                        count++;
                }

                else
                {
                    if (boardEasy[i][j + 1] == 9)
                        count++;
                    if (boardEasy[i][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j] == 9)
                        count++;
                    if (boardEasy[i - 1][j] == 9)
                        count++;
                    if (boardEasy[i + 1][j + 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j - 1] == 9)
                        count++;
                    if (boardEasy[i + 1][j - 1] == 9)
                        count++;
                    if (boardEasy[i - 1][j + 1] == 9)
                        count++;
                }
                boardEasy[i][j] = count;
            }
        }
    }
}

void Gamemode::openBoard(const int& row, const int& col)
{
    this->zeroClick(row, col);

    for (int i = 0; i < this->getRows(); i++)
    {
        for (int j = 0; j < this->getCol(); j++)
        {
            if (viewEasy[i][j] == 10 && openEasy[i][j] == 1)
            {
                this->zeroClick(i, j);
                i = 0;
                j = 0;
            }
        }
    }
}

///////////////////////////Menu Class Utility Fucntions///////////////////////////////////////////////

bool checkSettingsMenu(int& var, const int& x, const int& y)
{
    if (y >= 335 && y <= 410)
    {
        if (x >= 425 && x <= 545)
        {
            var = 1;
            return true;
        }
        if (x >= 590 && x <= 710)
        {
            var = 2;
            return true;
        }
        else if (x >= 745 && x <= 864)
        {
            var = 3;
            return true;
        }
    }
    return false;
}

void checkMainMenu(int& var, const int& x, const int& y)
{
    if (x >= 590 && x <= 710 && y >= 344 && y <= 370)
        var = 1;
    else if (x >= 585 && x <= 725 && y >= 385 && y <= 415)
        var = 2;
    else if (x >= 598 && x <= 710 && y >= 434 && y <= 465)
        var = 3;
}

/////////////////////////////Parent + Child Classes/////////////////////////////////////////////

class Menu
{
    int sizeX;
    int sizeY;
public:
    Menu()
    {
        sizeX = 0;
        sizeY = 0;
    }
    virtual bool display() = 0;
    friend class MainMenu;
    friend class SettingsMenu;
};

class SettingsMenu :public Menu
{
public:
    SettingsMenu()
    {
        sizeX = 1366;
        sizeY = 750;
    }
    virtual bool display()
    {

        sf::RenderWindow window(sf::VideoMode(sizeX, sizeY), "Minesweeper Settings", sf::Style::Close);
        sf::Texture settingsTexture;
        settingsTexture.loadFromFile("res/gfx/settings.png");
        sf::RectangleShape spriteSettings(sf::Vector2f(sizeX, sizeY));
        spriteSettings.setTexture(&settingsTexture);
        bool close = 0;

        while (window.isOpen() || close == 1)
        {
            sf::Event windowEvent;
            while (window.pollEvent(windowEvent))
            {
                if (windowEvent.type == windowEvent.Closed)
                {
                    window.clear();
                    window.close();
                }
                if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    Sleep(200);
                    if (checkSettingsMenu(difficulty, mousePos.x, mousePos.y))
                    {
                        goto b;
                    }
                }
            }
            window.draw(spriteSettings);
            window.display();
        }
 b:       return 1;
    }
};

class MainMenu : public Menu
{
public:
    MainMenu()
    {
        sizeX = 1366;
        sizeY = 750;
    }
    bool display()
    {
        SettingsMenu s1;
    a:  int selection = 0;
        bool exit = 0;
        sf::RenderWindow window(sf::VideoMode(1366, 750), "Minesweeper 1.0", sf::Style::Close);
        sf::Texture menuTexture;
        sf::RectangleShape spriteMenu(sf::Vector2f(1366, 750));
        menuTexture.loadFromFile("res/gfx/background.png");
        spriteMenu.setTexture(&menuTexture);
        sf::Event windowEvent;

        while (window.isOpen() && exit != 1)
        {
            while (window.pollEvent(windowEvent))
            {
                if (windowEvent.type == windowEvent.Closed)
                    window.close();
                if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    Sleep(200);
                    checkMainMenu(selection, mousePos.x, mousePos.y);
                    if (selection == 1)
                    {
                        exit = 1;
                        window.close();
                        chooseGame(difficulty);
                    }
                    else if (selection == 2)
                    {
                        selection = 0;
                        window.close();
                        if (s1.display())
                            goto a;
                    }
                    else if (selection == 3)
                        exit = 1;
                }
            }
            window.clear();
            window.draw(spriteMenu);
            window.display();
        }

        if (exit == 1)
            while (window.pollEvent(windowEvent))
            {
                if (windowEvent.type == windowEvent.Closed)
                {
                    window.close();
                }
            }
        return true;
    }
};

/////////////////////////////Utility Functions////////////////////////////////////////////

void Gamemode::mouseHoverPos(const int& x, const int& y, int& row, int& col)
{
    if (x >= 0 && x <= this->getCol() * 16 * this->getScale() && y >= 0 && y <= this->getRows() * 16 * this->getScale())
    {
        row = y / (16 * this->getScale());
        col = x / (16 * this->getScale());
    }
}

void displayNumbers(const int& row, const int& col, const int& num, const int& maxRow, const int& maxCol, const int& scale, sf::RenderWindow& window)
{
    sf::Texture texture;
    sf::RectangleShape number(sf::Vector2f(16, 16));
    if (flagEasy[row][col] == 0 && openEasy[row][col] == 1)
    {
        if (num == 0)
        {
            texture.loadFromFile("res/gfx/empty_tile.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 1)
        {
            texture.loadFromFile("res/gfx/one.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 2)
        {
            texture.loadFromFile("res/gfx/two.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 3)
        {
            texture.loadFromFile("res/gfx/three.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 4)
        {
            texture.loadFromFile("res/gfx/four.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 5)
        {
            texture.loadFromFile("res/gfx/five.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 6)
        {
            texture.loadFromFile("res/gfx/six.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 7)
        {
            texture.loadFromFile("res/gfx/seven.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 8)
        {
            texture.loadFromFile("res/gfx/eight.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 9)
        {
            texture.loadFromFile("res/gfx/mine.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
        else if (num == 10)
        {
            texture.loadFromFile("res/gfx/empty_tile.png");
            number.setTexture(&texture);
            number.setScale(scale, scale);
            number.setPosition(col * 16 * scale, row * 16 * scale);
        }
    }
    else if (flagEasy[row][col] == 1 && openEasy[row][col] == 0)
    {
        texture.loadFromFile("res/gfx/flag.png");
        number.setTexture(&texture);
        number.setScale(scale, scale);
        number.setPosition(col * 16 * scale, row * 16 * scale);
    }
    else if (openEasy[row][col] == 0 && flagEasy[row][col] == 0)
    {
        texture.loadFromFile("res/gfx/unclicked_tile.png");
        number.setTexture(&texture);
        number.setScale(scale, scale);
        number.setPosition(col * 16 * scale, row * 16 * scale);
    }
    else
    {
        texture.loadFromFile("res/gfx/empty_tile.png");
        number.setTexture(&texture);
        number.setScale(scale, scale);
        number.setPosition(col * 16 * scale, row * 16 * scale);
    }
    window.draw(number);
}

void Gamemode::drawView(sf::RenderWindow& window)
{
    /*sf::Texture tileTexture;
    tileTexture.loadFromFile("res/gfx/unclicked_tile.png");
    sf::RectangleShape spriteTile(sf::Vector2f(16, 16));
    spriteTile.setTexture(&tileTexture);
    spriteTile.setScale(this->getScale(), this->getScale());*/

    for (int i = 0; i < this->getRows(); i++)
        for (int j = 0; j < this->getCol(); j++)
            displayNumbers(i, j, viewEasy[i][j], this->getRows(), this->getCol(), this->getScale(), window);
}

void Gamemode::displayTimer(const sf::Time& time, sf::RenderWindow& window)
{
    int seconds = (int)time.asSeconds();
    int digitOne = 0;
    int digitTwo = 0;
    int digitThree = 0;

    int scale = this->getScale();

    digitOne = seconds % 10;
    if (seconds <= 99)
    {
        digitTwo = seconds / 10;
    }
    else
    {
        seconds /= 10;
        digitTwo = seconds % 10;
        digitThree = seconds / 10;
    }

    ////////////////////////////

    sf::Texture texture;
    sf::RectangleShape numMine(sf::Vector2f(13, 23));

    if (digitOne == 0)
    {
        texture.loadFromFile("res/gfx/digit_zero.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 1)
    {
        texture.loadFromFile("res/gfx/digit_one.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 2)
    {
        texture.loadFromFile("res/gfx/digit_two.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 3)
    {
        texture.loadFromFile("res/gfx/digit_three.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 4)
    {
        texture.loadFromFile("res/gfx/digit_four.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 5)
    {
        texture.loadFromFile("res/gfx/digit_five.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 6)
    {
        texture.loadFromFile("res/gfx/digit_six.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 7)
    {
        texture.loadFromFile("res/gfx/digit_seven.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 8)
    {
        texture.loadFromFile("res/gfx/digit_eight.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    else if (digitOne == 9)
    {
        texture.loadFromFile("res/gfx/digit_nine.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale * 2), (16 * scale * this->getRows()) + 30);
    }
    window.draw(numMine);

    ///////////////////////////////////////////////////////////

    if (digitTwo == 0)
    {
        if (seconds < 10)
            texture.loadFromFile("res/gfx/digit_blank.png");
        else
            texture.loadFromFile("res/gfx/digit_zero.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 1)
    {
        texture.loadFromFile("res/gfx/digit_one.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 2)
    {
        texture.loadFromFile("res/gfx/digit_two.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 3)
    {
        texture.loadFromFile("res/gfx/digit_three.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 4)
    {
        texture.loadFromFile("res/gfx/digit_four.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 5)
    {
        texture.loadFromFile("res/gfx/digit_five.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 6)
    {
        texture.loadFromFile("res/gfx/digit_six.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 7)
    {
        texture.loadFromFile("res/gfx/digit_seven.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 8)
    {
        texture.loadFromFile("res/gfx/digit_eight.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    else if (digitTwo == 9)
    {
        texture.loadFromFile("res/gfx/digit_nine.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30 + (13 * scale), (16 * scale * this->getRows()) + 30);
    }
    window.draw(numMine);

    ///////////////////////////////////////////////////////////

    if (digitThree == 0)
    {
        texture.loadFromFile("res/gfx/digit_blank.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 1)
    {
        texture.loadFromFile("res/gfx/digit_one.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 2)
    {
        texture.loadFromFile("res/gfx/digit_two.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 3)
    {
        texture.loadFromFile("res/gfx/digit_three.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 4)
    {
        texture.loadFromFile("res/gfx/digit_four.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 5)
    {
        texture.loadFromFile("res/gfx/digit_five.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 6)
    {
        texture.loadFromFile("res/gfx/digit_six.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 7)
    {
        texture.loadFromFile("res/gfx/digit_seven.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 8)
    {
        texture.loadFromFile("res/gfx/digit_eight.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    else if (digitThree == 9)
    {
        texture.loadFromFile("res/gfx/digit_nine.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition(30, (16 * scale * this->getRows()) + 30);
    }
    window.draw(numMine);
}

void Gamemode::displayNumMines(sf::RenderWindow& window)
{
    sf::Texture texture;
    sf::RectangleShape numMine(sf::Vector2f(13, 23));

    sf::RectangleShape infoBar(sf::Vector2f(837, 147));
    texture.loadFromFile("res/gfx/info_bar.png");
    infoBar.setTexture(&texture);
    infoBar.setScale((float)(16 * this->getScale() * this->getCol()) / 837, (float)1);
    infoBar.setPosition(0, 16 * this->getScale() * this->getRows());

    window.draw(infoBar);

    int temp = remMines;
    int scale = this->getScale();

    if (temp >= 0)
    {
        texture.loadFromFile("res/gfx/digit_blank.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (13 * scale * 2), (scale * this->getRows() * 16) + 30);
    }
    else if (temp < 0)
    {
        texture.loadFromFile("res/gfx/digit_minus.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (13 * scale * 2), (scale * this->getRows() * 16) + 30);
        temp *= -1;
    }
    window.draw(numMine);

    /////////////////////////////////////////////

    int digitOne = temp % 10;
    if (digitOne == 0)
    {
        texture.loadFromFile("res/gfx/digit_zero.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 1)
    {
        texture.loadFromFile("res/gfx/digit_one.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 2)
    {
        texture.loadFromFile("res/gfx/digit_two.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 3)
    {
        texture.loadFromFile("res/gfx/digit_three.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 4)
    {
        texture.loadFromFile("res/gfx/digit_four.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 5)
    {
        texture.loadFromFile("res/gfx/digit_five.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 6)
    {
        texture.loadFromFile("res/gfx/digit_six.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 7)
    {
        texture.loadFromFile("res/gfx/digit_seven.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 8)
    {
        texture.loadFromFile("res/gfx/digit_eight.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    else if (digitOne == 9)
    {
        texture.loadFromFile("res/gfx/digit_nine.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80, (scale * this->getRows() * 16) + 30);
    }
    window.draw(numMine);

    ///////////////////////////////////////////////////////////

    int digitTwo = temp / 10;
    if (digitTwo == 0)
    {
        texture.loadFromFile("res/gfx/digit_zero.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 1)
    {
        texture.loadFromFile("res/gfx/digit_one.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 2)
    {
        texture.loadFromFile("res/gfx/digit_two.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 3)
    {
        texture.loadFromFile("res/gfx/digit_three.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 4)
    {
        texture.loadFromFile("res/gfx/digit_four.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 5)
    {
        texture.loadFromFile("res/gfx/digit_five.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 6)
    {
        texture.loadFromFile("res/gfx/digit_six.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 7)
    {
        texture.loadFromFile("res/gfx/digit_seven.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 8)
    {
        texture.loadFromFile("res/gfx/digit_eight.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }
    else if (digitTwo == 9)
    {
        texture.loadFromFile("res/gfx/digit_nine.png");
        numMine.setTexture(&texture);
        numMine.setScale(scale, scale);
        numMine.setPosition((scale * this->getCol() * 16) - 80 - (scale * 13), (scale * this->getRows() * 16) + 30);
    }

    window.draw(numMine);
}

////////////////////////////////Child Classes of Gamemode////////////////////////////////////////

class EasyGame : public Gamemode
{
public:
    EasyGame()
    {
        maxRows = 9;
        maxCol = 9;
        scale = 4;
        numMines = 10;
    }
    void startGame()
    {
        Gamemode g(9, 9, 4, 10);
        g.gameLoop();
    }
};

class MediumGame : public Gamemode
{
public:
    MediumGame()
    {
        maxRows = 16;
        maxCol = 16;
        scale = 3;
        numMines = 40;
    }
    void startGame()
    {
        Gamemode g(16, 16, 3, 40);
        g.gameLoop();
    }
};

class HardGame : public Gamemode
{
public:
    HardGame()
    {
        maxRows = 16;
        maxCol = 30;
        scale = 2;
        numMines = 99;
    }
    void startGame()
    {
        Gamemode g(16, 30, 2, 99);
        g.gameLoop();
    }
};

/////////////////////////////////Gamemode Class Utility Functions///////////////////////////////////////

void chooseGame(const int& difficulty)
{
    if (difficulty == 1)
    {
        EasyGame easy;
        easy.startGame();
    }
    else if (difficulty == 2)
    {
        MediumGame med;
        med.startGame();
    }
    else if (difficulty == 3)
    {
        HardGame hard;
        hard.startGame();
    }
}

void Gamemode::zeroClick(const int& i, const int& j)
{
    if (i == 0 && j == 0)
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i + 1][j + 1] == 0)
        {
            viewEasy[i + 1][j + 1] = boardEasy[i + 1][j + 1];
            openEasy[i + 1][j + 1] = 1;
            if (boardEasy[i + 1][j + 1] == 0)
                viewEasy[i + 1][j + 1] = 10;
        }
    }
    else if (i == 0 && j == this->getCol() - 1)
    {
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i + 1][j - 1] == 0)
        {
            viewEasy[i + 1][j - 1] = boardEasy[i + 1][j - 1];
            openEasy[i + 1][j - 1] = 1;
            if (boardEasy[i + 1][j - 1] == 0)
                viewEasy[i + 1][j - 1] = 10;
        }
    }
    else if (i == this->getRows() - 1 && j == 0)
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i - 1][j + 1] == 0)
        {
            viewEasy[i - 1][j + 1] = boardEasy[i - 1][j + 1];
            openEasy[i - 1][j + 1] = 1;
            if (boardEasy[i - 1][j + 1] == 0)
                viewEasy[i - 1][j + 1] = 10;
        }
    }
    else if (i == this->getRows() - 1 && j == this->getCol() - 1)
    {
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i - 1][j - 1] == 0)
        {
            viewEasy[i - 1][j - 1] = boardEasy[i - 1][j - 1];
            openEasy[i - 1][j - 1] = 1;
            if (boardEasy[i - 1][j - 1] == 0)
                viewEasy[i - 1][j - 1] = 10;
        }
    }
    else if (i == 0)
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i + 1][j + 1] == 0)
        {
            viewEasy[i + 1][j + 1] = boardEasy[i + 1][j + 1];
            openEasy[i + 1][j + 1] = 1;
            if (boardEasy[i + 1][j + 1] == 0)
                viewEasy[i + 1][j + 1] = 10;
        }
        if (openEasy[i + 1][j - 1] == 0)
        {
            viewEasy[i + 1][j - 1] = boardEasy[i + 1][j - 1];
            openEasy[i + 1][j - 1] = 1;
            if (boardEasy[i + 1][j - 1] == 0)
                viewEasy[i + 1][j - 1] = 10;
        }
    }
    else if (i == this->getRows() - 1)
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i - 1][j - 1] == 0)
        {
            viewEasy[i - 1][j - 1] = boardEasy[i - 1][j - 1];
            openEasy[i - 1][j - 1] = 1;
            if (boardEasy[i - 1][j - 1] == 0)
                viewEasy[i - 1][j - 1] = 10;
        }
        if (openEasy[i - 1][j + 1] == 0)
        {
            viewEasy[i - 1][j + 1] = boardEasy[i - 1][j + 1];
            openEasy[i - 1][j + 1] = 1;
            if (boardEasy[i - 1][j + 1] == 0)
                viewEasy[i - 1][j + 1] = 10;
        }
    }
    else if (j == 0)
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i + 1][j + 1] == 0)
        {
            viewEasy[i + 1][j + 1] = boardEasy[i + 1][j + 1];
            openEasy[i + 1][j + 1] = 1;
            if (boardEasy[i + 1][j + 1] == 0)
                viewEasy[i + 1][j + 1] = 10;
        }
        if (openEasy[i - 1][j + 1] == 0)
        {
            viewEasy[i - 1][j + 1] = boardEasy[i - 1][j + 1];
            openEasy[i - 1][j + 1] = 1;
            if (boardEasy[i - 1][j + 1] == 0)
                viewEasy[i - 1][j + 1] = 10;
        }

    }
    else if (j == this->getCol() - 1)
    {
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i - 1][j - 1] == 0)
        {
            viewEasy[i - 1][j - 1] = boardEasy[i - 1][j - 1];
            openEasy[i - 1][j - 1] = 1;
            if (boardEasy[i - 1][j - 1] == 0)
                viewEasy[i - 1][j - 1] = 10;
        }
        if (openEasy[i + 1][j - 1] == 0)
        {
            viewEasy[i + 1][j - 1] = boardEasy[i + 1][j - 1];
            openEasy[i + 1][j - 1] = 1;
            if (boardEasy[i + 1][j - 1] == 0)
                viewEasy[i + 1][j - 1] = 10;
        }
    }
    else
    {
        if (openEasy[i][j + 1] == 0)
        {
            viewEasy[i][j + 1] = boardEasy[i][j + 1];
            openEasy[i][j + 1] = 1;
            if (boardEasy[i][j + 1] == 0)
                viewEasy[i][j + 1] = 10;
        }
        if (openEasy[i][j - 1] == 0)
        {
            viewEasy[i][j - 1] = boardEasy[i][j - 1];
            openEasy[i][j - 1] = 1;
            if (boardEasy[i][j - 1] == 0)
                viewEasy[i][j - 1] = 10;
        }
        if (openEasy[i + 1][j] == 0)
        {
            viewEasy[i + 1][j] = boardEasy[i + 1][j];
            openEasy[i + 1][j] = 1;
            if (boardEasy[i + 1][j] == 0)
                viewEasy[i + 1][j] = 10;
        }
        if (openEasy[i - 1][j] == 0)
        {
            viewEasy[i - 1][j] = boardEasy[i - 1][j];
            openEasy[i - 1][j] = 1;
            if (boardEasy[i - 1][j] == 0)
                viewEasy[i - 1][j] = 10;
        }
        if (openEasy[i + 1][j + 1] == 0)
        {
            viewEasy[i + 1][j + 1] = boardEasy[i + 1][j + 1];
            openEasy[i + 1][j + 1] = 1;
            if (boardEasy[i + 1][j + 1] == 0)
                viewEasy[i + 1][j + 1] = 10;
        }
        if (openEasy[i - 1][j - 1] == 0)
        {
            viewEasy[i - 1][j - 1] = boardEasy[i - 1][j - 1];
            openEasy[i - 1][j - 1] = 1;
            if (boardEasy[i - 1][j - 1] == 0)
                viewEasy[i - 1][j - 1] = 10;
        }
        if (openEasy[i + 1][j - 1] == 0)
        {
            viewEasy[i + 1][j - 1] = boardEasy[i + 1][j - 1];
            openEasy[i + 1][j - 1] = 1;
            if (boardEasy[i + 1][j - 1] == 0)
                viewEasy[i + 1][j - 1] = 10;
        }
        if (openEasy[i - 1][j + 1] == 0)
        {
            viewEasy[i - 1][j + 1] = boardEasy[i - 1][j + 1];
            openEasy[i - 1][j + 1] = 1;
            if (boardEasy[i - 1][j + 1] == 0)
                viewEasy[i - 1][j + 1] = 10;
        }
    }
    viewEasy[i][j] = 0;
}

int checkExit(const int& x, const int& y)
{
    if (x >= 260 && x <= 495)
    {
        if (y >= 145 && y <= 220)
            return 1;
        else if (y >= 290 && y <= 365)
            return 2;
    }
}

void enterLeaderboard(int userScore)
{
    char userName[10] = "empty";
    char name[5][10] = { "/0" };
    int score[5] = { 0 };
    char path[100] = "leaderboard_easy.txt";
    if (difficulty == 2)
        strcpy_s(path, "leaderboard_medium.txt");
    else if (difficulty == 3)
        strcpy_s(path, "leaderboard_hard.txt");
    std::ifstream fin(path);
    for (int i = 0; i < 5; i++)
    {
        fin >> score[i];
        fin >> name[i];
    }
    for (int i = 0; i < 4; i++)
    {
        if (score[i] > score[i + 1])
        {
            std::swap(score[i], score[i + 1]);
            std::swap(name[i], name[i + 1]);
            i = 0;
        }
    }

    if (userScore < score[4])
    {
        std::swap(userScore, score[4]);
        std::cout << "Enter Name: ";
        std::cin >> userName;
        std::swap(userName, name[4]);
    }

    for (int i = 0; i < 5; i++)
    {
        for(int j=i+1; j<5; j++)
            if (score[i] > score[j])
            {
                std::swap(score[i], score[j]);
                std::swap(name[i], name[j]);
            }
    }
    fin.close();

    std::ofstream fout(path);
    for (int i = 0; i < 5; i++)
    {
        fout << score[i] << "\t";
        fout << name[i] << "\n";
    }
    fout.close();

    std::cout << "\nTime\tName\t\n";
    for (int i = 0; i < 5; i++)
    {
        std::cout << score[i] << "\t";
        std::cout << name[i] << "\n";
    }
}

void endGame(int score, bool win)
{
    sf::RenderWindow exitWindow(sf::VideoMode(783, 430), "Game has Ended! ", sf::Style::Close);
    bool inputName = 0;
    int selected = 0;

    sf::Texture tileTexture;
    if (win == 1)
    {
        if (checkLeaderboard(score) == 1)
        {
            tileTexture.loadFromFile("res/gfx/exit_menu_score.png");
            inputName = 1;
        }
        else
            tileTexture.loadFromFile("res/gfx/exit_menu_won.png");
    }
    else
        tileTexture.loadFromFile("res/gfx/exit_menu_lost.png");

    sf::RectangleShape spriteTile(sf::Vector2f(783, 430));
    spriteTile.setTexture(&tileTexture);

    while (exitWindow.isOpen())
    {
        sf::Event event;
        while (exitWindow.pollEvent(event))
        {
            if (event.type == event.Closed)
                exitWindow.close();
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
            {
                Sleep(200);
                sf::Vector2i mousePos = sf::Mouse::getPosition(exitWindow);
                selected = checkExit(mousePos.x, mousePos.y);
                goto z;
            }
        }
        exitWindow.clear();
        exitWindow.draw(spriteTile);
        exitWindow.display();
    }
z:    exitWindow.close();

    for (int i = 0; i < 16; i++)
    {
        for (int j = 0; j < 30; j++)
        {
            boardEasy[i][j] = 0;
            viewEasy[i][j] = -1;
            flagEasy[i][j] = 0;
            openEasy[i][j] = 0;
        }
    }

    if (win == 1)
    {
        if (checkLeaderboard(score) == 1)
        {
            enterLeaderboard(score);
        }
    }

    if (selected == 2)
    {
        MainMenu obj1;
        obj1.display();
    }
    else if (selected == 1)
    {
        chooseGame(difficulty);
    }
}

bool Gamemode::checkWin()
{
    int count = 0;
    for (int i = 0; i < this->getRows(); i++)
    {
        for (int j = 0; j < this->getCol(); j++)
        {
            if (openEasy[i][j] == 1)
                count++;
        }
    }

    if (count == this->getRows() * this->getCol() - this->getMines())
        return true;
    else
        return false;
}

void Gamemode::gameLoop()
{
    sf::RenderWindow window(sf::VideoMode(16 * this->getScale() * this->getCol(), 16 * this->getScale() * this->getRows() + 150), "Minesweeper 1.0", sf::Style::Close);
    window.setFramerateLimit(10);

    sf::Texture tileTexture;
    tileTexture.loadFromFile("res/gfx/unclicked_tile.png");
    sf::RectangleShape spriteTile(sf::Vector2f(16, 16));
    spriteTile.setTexture(&tileTexture);
    spriteTile.setScale(this->getScale(), this->getScale());

    setMine(this->getRows(), this->getCol(), this->getMines());

    int score = 0;

    bool gameEnd = 0;

    for (int i = 0; i < this->getRows(); i++)
    {
        for (int j = 0; j < this->getCol(); j++)
        {
            if (boardEasy[i][j] != 9)
                std::cout << boardEasy[i][j] << "  ";
            else
                std::cout << "X  ";
        }
        std::cout << std::endl;
    }

    for (int j = 0; j < this->getCol(); j++)
        for (int i = 0; i < this->getRows(); i++)
        {
            spriteTile.setPosition(sf::Vector2f(i * 16 * this->getScale(), j * 16 * this->getScale()));
            window.draw(spriteTile);
        }

    sf::Clock clock;

    while (window.isOpen() && gameEnd != 1)
    {
        sf::Event windowEvent;
        sf::Time elapsed = clock.getElapsedTime();
        while (window.pollEvent(windowEvent))
        {
            if (windowEvent.type == windowEvent.Closed)
                window.close();
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
            {
                Sleep(200);
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                int clickedRow = -1;
                int clickedCol = -1;
                this->mouseHoverPos(mousePos.x, mousePos.y, clickedRow, clickedCol);
                if (flagEasy[clickedRow][clickedCol] != 1)
                {
                    viewEasy[clickedRow][clickedCol] = boardEasy[clickedRow][clickedCol];
                    openEasy[clickedRow][clickedCol] = 1;

                    if (viewEasy[clickedRow][clickedCol] == 0)
                    {
                        this->openBoard(clickedRow, clickedCol);
                    }
                    if (viewEasy[clickedRow][clickedCol] == 9)
                    {
                        gameEnd = 1;
                        for (int i = 0; i < this->getRows(); i++)
                            for (int j = 0; j < this->getCol(); j++)
                            {
                                openEasy[i][j] = 1;
                                flagEasy[i][j] = 0;
                                viewEasy[i][j] = boardEasy[i][j];
                            }
                    }
                }
                if (this->checkWin())
                {
                    gameEnd = 1;
                }
            }
            if (sf::Mouse::isButtonPressed(sf::Mouse::Right))
            {
                Sleep(200);
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                int clickedRow = -1;
                int clickedCol = -1;
                this->mouseHoverPos(mousePos.x, mousePos.y, clickedRow, clickedCol);
                if (openEasy[clickedRow][clickedCol] != 1)
                {
                    if (flagEasy[clickedRow][clickedCol] == 0)
                    {
                        flagEasy[clickedRow][clickedCol] = 1;
                        remMines--;
                    }
                    else
                    {
                        flagEasy[clickedRow][clickedCol] = 0;
                        remMines++;
                    }
                }
            }
        }
        score = elapsed.asSeconds();
        window.clear();
        this->drawView(window);
        this->displayNumMines(window);
        this->displayTimer(elapsed, window);
        window.display();
    }
    std::cout << "\nGame has Ended\n";

    bool close = 0;
    while (window.isOpen() && close != 1)
    {
        sf::Event windowEvent;
        while (window.pollEvent(windowEvent))
        {
            if (windowEvent.type == windowEvent.Closed)
                window.close();
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left) || sf::Mouse::isButtonPressed(sf::Mouse::Right))
            {
                Sleep(200);
                close = 1;
            }
        }
    }

    window.close();
    endGame(score, this->checkWin());
}

bool checkLeaderboard(const int& userScore)
{
    int score[5] = { 0 };
    std::ifstream fin("leaderboard_easy.txt");
    for (int i = 0; i < 5; i++)
    {
        fin >> score[i];
    }

    for (int i = 0; i < 4; i++)
        if (score[i] > score[i + 1])
            std::swap(score[i], score[i + 1]);

    if (userScore <= score[4] || score[4] == 0)
        return true;
    else
        return false;
}
