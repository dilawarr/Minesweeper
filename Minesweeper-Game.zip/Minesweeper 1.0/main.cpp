#include "Game.h"
int main()
{
	MainMenu obj;
	obj.display();
	return EXIT_SUCCESS;

}